export const Type = {
  HOME: "HOME",
};
